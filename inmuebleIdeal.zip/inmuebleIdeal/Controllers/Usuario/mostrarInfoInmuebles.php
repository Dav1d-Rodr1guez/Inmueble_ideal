<?php

function cargarInmueble(){
    $objConsultas=new consultasUser();

    $result = $objConsultas -> consultarInmuebles();

    if (!isset($result)) {

        //resultado vacido
        echo "<h2>No hay inmuebles registrados</h2>";

    } else{
        //reultado con datos 

        foreach($result as $f){
        //pintamos el html de la interfaz dentro de un echo 
        echo '
            <div class="card-inmueble">
                <img src="'.$f['foto'].'" alt="">
                <div class="info-card">
                    <h4>Valor de '.$f['categoria'].':</h4>
                    <h2>$'.$f['precio'].'</h2>
                    <p>'.$f['tipo'].' - '.$f['tamano'].' m2</p>
                    <p class="direccion">'.$f['ciudad'].'/'.$f['barrio'].'</p>
                    <a href="UserShowInmueble.php?id='.$f['id'].'">Ver Más</a>
                </div>
            </div>';
        }
    }
}
function cargarVistaInmueble() {
    $id_user = $_SESSION['id'];
    $id = $_GET['id'];
    $objConsultas = new consultasUser();
    $result = $objConsultas->consultarVistaInmueble($id);

    if (!$result) {
        // Si no se encuentra el inmueble
        echo "<h2>Inmueble no encontrado</h2>";
    } else {
        // Mostrar los detalles del inmueble encontrado
        echo '
        <figure class="photo-preview">
            <img src="' . $result['foto'] . '" alt="">
        </figure>
        <div class="cont-details">
            <div>
                <article class="info-name"><p>' . $result['tipo'] . '</p></article>
                <article class="info-category"><p>' . $result['categoria'] . '</p></article>
                <article class="info-precio"><p>$' . number_format($result['precio'], 0, ',', '.') . '</p></article>
                <article class="info-direccion"><p>' . $result['ciudad'] . '/' . $result['barrio'] . '</p></article>
                <article class="info-tamano"><p>' . $result['tamano'] . ' m2</p></article>';

      
        echo '<a href="../../Controllers/Usuario/insertarSolicitud.php?id=' . $result['id'] . '&id_user=' . $id_user . '" class="btn-home">Solicitar cita</a>';
        echo '
            </div>
        </div>';
    }
}



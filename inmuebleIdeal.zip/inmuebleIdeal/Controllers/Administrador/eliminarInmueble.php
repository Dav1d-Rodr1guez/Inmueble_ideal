<?php
// Importar las dependencias
require_once("../../Models/conexionDb.php");
require_once("../../Models/consultasAdmin.php");

// Verificar si se ha enviado el ID por GET
if (isset($_GET['id'])) {
    // Obtener el ID del inmueble a eliminar
    $id = $_GET['id'];

    // Crear una instancia de ConsultasAdmin
    $objConsultas = new ConsultasAdmin();

    // Llamar al método eliminarInmueble para eliminar el inmueble por su ID
    $result = $objConsultas->eliminarInmueble($id);

    if ($result) {
        // Éxito al eliminar el inmueble
        echo "<script>alert('Inmueble eliminado exitosamente');</script>";
    } else {
        // Error al eliminar el inmueble
        echo "<script>alert('Error al eliminar el inmueble');</script>";
    }
} else {
    // Si no se proporcionó el ID, redireccionar o mostrar un mensaje de error
    echo "<script>alert('Error: ID de inmueble no proporcionado');</script>";
}

// Redireccionar a la página de consulta de inmuebles después de eliminar
echo "<script>location.href='../../Views/interfaces/InmoApartamentos.php';</script>";
?>

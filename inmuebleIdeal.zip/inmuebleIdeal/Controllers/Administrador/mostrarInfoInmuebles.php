<?php

function cargarInmueble(){
    $objConsultas=new consultasAdmin();

    $result = $objConsultas -> consultarInmuebles();

    if (!isset($result)) {

        //resultado vacido
        echo "<h2>No hay inmuebles registrados</h2>";

    } else{
        //reultado con datos 

        foreach($result as $f){
        //pintamos el html de la interfaz dentro de un echo 
        echo '
        <tr>
            <td>
                <figure class="photo">
                    <img src="'.$f['foto'].'" alt="">
                </figure>
                <div class="info">
                    <h3>'.$f['tipo'].'</h3>
                    <h4>$'.$f['precio'].'</h4>
                    <p>'.$f['ciudad'].'/'.$f['barrio'].'</p>
                </div>
                <div class="controls">
                    
                    <a href="../../views/interfaces/InmoEdit.php?id='.$f['id'].'" class="edit"></a>
                    <a href="../../Controllers/Administrador/eliminarInmueble.php?id='.$f['id'].'" class="delete"></a>
                </div>
            </td>
        </tr>';
        }
    }
}
function cargarInmueblesEdit() {
    // Capturamos el ID del inmueble desde el parámetro GET
    $id_inmueble = $_GET['id'];

    // Creamos una instancia de la clase ConsultasAdmin
    $objConsultas = new ConsultasAdmin();

    // Consultamos la información del inmueble específico por su ID
    $result = $objConsultas->consultarInmuebleEdit($id_inmueble);

    // Verificamos si se encontraron resultados
    if ($result) {
        // Iteramos sobre los resultados (debería ser solo uno, ya que es por ID)
        foreach ($result as $f) {
            echo '
            <form action="../../Controllers/Administrador/editarInmueble.php" method="POST" id="step-form-horizontal" class="step-form-horizontal" enctype="multipart/form-data">
                <input type="hidden" name="id" value="'.$f['id'].'"> <!-- Campo oculto con el ID del inmueble -->
                <div class="select">
                    <select name="tipo">
                        <option value="">Seleccione Tipo de Inmueble...</option>
                        <option value="Apartamento" '.($f['tipo'] == "Apartamento" ? "selected" : "").'>Apartamento</option>
                        <option value="Aparta Estudio" '.($f['tipo'] == "Aparta Estudio" ? "selected" : "").'>Aparta Estudio</option>
                        <option value="Casa" '.($f['tipo'] == "Casa" ? "selected" : "").'>Casa</option>
                    </select>
                </div>
                <div class="select">
                    <select name="categoria">
                        <option value="">Seleccione Categoría...</option>
                        <option value="Arriendo" '.($f['categoria'] == "Arriendo" ? "selected" : "").'>Arriendo</option>
                        <option value="Venta" '.($f['categoria'] == "Venta" ? "selected" : "").'>Venta</option>
                    </select>
                </div>
                <input type="number" name="precio" placeholder="Precio..." value="'.$f['precio'].'" required>
                <input type="number" name="tamano" placeholder="Tamaño..." value="'.$f['tamano'].'" required>
                <input type="text" name="ciudad" placeholder="Ciudad..." value="'.$f['ciudad'].'" required>
                <input type="text" name="barrio" placeholder="Localidad/Barrio..." value="'.$f['barrio'].'" required>
                
                <button type="submit" class="btn-home">Modificar</button>
            </form>
            ';
        }
    } else {
        echo "<p>No se encontró el inmueble.</p>";
    }
}

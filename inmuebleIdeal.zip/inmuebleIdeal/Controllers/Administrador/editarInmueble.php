<?php
// IMPORTAMOS LAS DEPENDENCIAS
require_once("../../Models/conexionDb.php");
require_once("../../Models/consultasAdmin.php");

// CAPTURAMOS EN VARIABLES LOS DATOS ENVIADOS DESDE EL FORMULARIO A PARTIR DEL METHODO POST Y LOS NAME DE LOS CAMPOS
$id = $_POST['id'];
$tipo = $_POST['tipo'];
$categoria = $_POST['categoria'];
$precio = $_POST['precio'];
$tamano = $_POST['tamano'];
$ciudad = $_POST['ciudad'];
$barrio = $_POST['barrio'];

// CREAMOS EL OBJETO A PARTIR DE LA CLASE CONSULTAS PARA ENVIAR LOS VALORES A UNA FUNCIÓN ESPECÍFICA
$objConsultas = new ConsultasAdmin();
$result = $objConsultas->editarInmueble($id, $tipo, $categoria, $precio, $tamano, $ciudad, $barrio);

if ($result) {
    // Inmueble editado correctamente
    echo "<script>alert('Inmueble editado correctamente');</script>";
    echo "<script>window.location.href='../../Views/interfaces/InmoApartamentos.php';</script>";
} else {
    // Error al editar el inmueble
    echo "<script>window.location.href='../../Views/interfaces/InmoApartamentos.php';</script>";
}
?>

<?php
require_once("../../Models/conexionDb.php");
require_once("../../Models/consultasAdmin.php");
session_start();

// Verificar si se ha enviado un formulario con una foto y la sesión está iniciada
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["foto"]) && isset($_SESSION["id"])) {
    // Obtener el ID del usuario de la sesión y la foto enviada
    $userId = $_SESSION["id"];
    $foto = $_FILES["foto"];

    // Ruta donde se guardarán las fotos (ajusta según tu estructura de archivos)
    $rutaFotos = "../../Uploads/";

    // Nombre de la foto en el servidor
    $nombreFoto = $foto["name"];
    // Ruta completa de la foto en el servidor
    $rutaCompleta = $rutaFotos . $nombreFoto;

    // Mover la foto al directorio de destino
    if (move_uploaded_file($foto["tmp_name"], $rutaCompleta)) {
        // Si la foto se movió correctamente, obtener otros datos del formulario
        $tipo = $_POST['tipo'];
        $categoria = $_POST['categoria'];
        $precio = $_POST['precio'];
        $tamano = $_POST['tamano'];
        $ciudad = $_POST['ciudad'];
        $barrio = $_POST['barrio'];

        // Validar campos obligatorios (ejemplo simple, ajusta según necesidad)
        if (empty($tipo) || empty($categoria) || empty($precio) || empty($tamano) || empty($ciudad) || empty($barrio)) {
            echo "<script>alert('Por favor complete todos los campos');</script>";
            echo "<script>window.location.href='../../Views/interfaces/InmoApartamentos.php';</script>";
            exit; // Detener la ejecución si hay campos vacíos
        }

        // Insertar en la base de datos
        $objConsultas = new ConsultasAdmin();
        $result = $objConsultas->agregarInmueble($tipo, $categoria, $precio, $tamano, $ciudad, $barrio, $rutaCompleta);

        if ($result) {
            // Inmueble agregado correctamente
            echo "<script>alert('Inmueble agregado correctamente');</script>";
            echo "<script>window.location.href='../../Views/interfaces/InmoApartamentos.php';</script>";
        } else {
            // Error al agregar el inmueble
            echo "<script>alert('Error al agregar el inmueble');</script>";
            echo "<script>window.location.href='../../Views/interfaces/InmoApartamentos.php';</script>";
        }
    } else {
        // Error al mover la foto al directorio de destino
        echo "<script>alert('Error al subir la foto');</script>";
        // echo "<script>window.location.href='../../Views/Extras/Login.html';</script>";
    }
} else {
    // Si no se enviaron los datos esperados, redireccionar o mostrar un mensaje de error
    echo "<script>alert('Error: datos incorrectos o faltantes');</script>";
    echo "<script>window.location.href='../../Views/interfaces/InmoApartamentos.php';</script>";
}
?>

<?php

// CLASE PARA REALIZAR LA CONSULTA
class ValidarSesion{
    // FUNCIÓN PARA INICIAR SESIÓN
    public function iniciarSesion($email, $clave){

        // CREAMOS LA CONEXIÓN DEL OBJETO
        $objConexion = new Connection();
        $conexion = $objConexion->open();

        // DEFINIMOS LA CONSULTA DML A EJECUTAR SQL
        $consulta = "SELECT * FROM usuarios WHERE correo=:email";

        // PREPARAMOS LO NECESARIO PARA EJECUTAR LA CONSULTA SQL
        $result = $conexion->prepare($consulta);

        // CONVERTIMOS LOS ARGUMENTOS EN PARAMETROS
        $result->bindParam(':email', $email);

        // EJECUTAMOS LA CONSULTA
        $result->execute();

        // ESTE IF VALIDA SI EL EMAIL SE ENCUENTRA EN LA BASE DE DATOS
        if ($f = $result->fetch()) {

            // VALIDAMOS LA CLAVE
            if ($f['clave'] == $clave){

                session_start();

                // CREAMOS VARIABLES DE SESIÓN GLOBALES
                $_SESSION['id'] = $f['id'];
                $_SESSION['email'] = $f['correo'];
                $_SESSION['rol'] = $f['rol'];
                $_SESSION['aut'] = "SI";

                // VALIDAMOS EL ROL PARA REDIRECCIONAMIENTO
                switch ($f['rol']) {
                    case '1':
                        echo "<script> alert('Bienvenido Usuario')</script>";
                        echo "<script> location.href='../Views/interfaces/UserDashboard.php'</script>";
                        break;

                    case '2':
                        echo "<script> alert('Bienvenido Administrador')</script>";
                        echo "<script> location.href='../Views/interfaces/InmoDashboard.php'</script>";
                        break;    

                    default:
                        echo "<script> alert('Su cuenta no tiene ningún ROL asignado, contáctenos')</script>";
                        echo "<script> location.href='../Views/interfaces/login.html'</script>";
                        break;
                }
                
            } else {
                echo "<script> alert('La clave no está bien escrita.')</script>";
                echo "<script> location.href='../Views/interfaces/login.html'</script>";
            }
        } else {
            echo "<script> alert('El email no existe en la base de datos')</script>";
            echo "<script> location.href='../Views/interfaces/login.html'</script>";
        }
    }

    // FUNCIÓN PARA CAMBIAR CONTRASEÑA
    public function cambiarContraseña($id, $contraseñaAnterior, $contraseñaNueva) {
        // CREAMOS LA CONEXIÓN DEL OBJETO
        $objConexion = new Connection();
        $conexion = $objConexion->open();
    
        // CONSULTAMOS LA CONTRASEÑA ACTUAL DEL USUARIO
        $consulta = "SELECT clave FROM usuarios WHERE identificacion = :id";
        $stmt = $conexion->prepare($consulta);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
        // VERIFICAMOS SI LA CONTRASEÑA ANTERIOR COINCIDE
        if ($usuario && $usuario['clave'] === md5($contraseñaAnterior)) {  // Usamos md5 para comparar la contraseña anterior
            // ENCRIPTAMOS LA NUEVA CONTRASEÑA
            $contraseñaNuevaEncriptada = md5($contraseñaNueva);
    
            // DEFINIMOS LA CONSULTA DML A EJECUTAR SQL
            $modificar = "UPDATE usuarios SET clave = :clave WHERE identificacion = :id";
            $result = $conexion->prepare($modificar);
            $result->bindParam(':id', $id);
            $result->bindParam(':clave', $contraseñaNuevaEncriptada);
            $result->execute();
    
            $objConexion->close();
            return true;
        } else {
            $objConexion->close();
            return false;
        }
    }   
}
?>

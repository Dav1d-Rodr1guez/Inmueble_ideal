<?php

// Importar las dependencias necesarias
require_once("conexionDb.php");

class ConsultasAdmin {

    // Registrar un inmueble con foto
    public function agregarInmueble($tipo, $categoria, $precio, $tamano, $ciudad, $barrio, $rutaFoto) {
    $objConexion = new Connection();
    $conexion = $objConexion->open();

    $registrar = "INSERT INTO inmuebles (tipo, categoria, precio, tamano, ciudad, barrio, foto) 
                  VALUES (:tipo, :categoria, :precio, :tamano, :ciudad, :barrio, :rutaFoto)";
    $result = $conexion->prepare($registrar);
    $result->bindParam(':tipo', $tipo);
    $result->bindParam(':categoria', $categoria);
    $result->bindParam(':precio', $precio);
    $result->bindParam(':tamano', $tamano);
    $result->bindParam(':ciudad', $ciudad);
    $result->bindParam(':barrio', $barrio);
    $result->bindParam(':rutaFoto', $rutaFoto);
    $result->execute();

    return $result->rowCount() > 0;
}
    

    // Consultar inmuebles
    public function consultarInmuebles() {
        $objConexion = new Connection();
        $conexion = $objConexion->open();

        $consultar = "SELECT * FROM inmuebles";
        $result = $conexion->prepare($consultar);
        $result->execute();

        $f = null;
        while ($resultado = $result->fetch()) {
            $f[] = $resultado;
        }
        return $f;
    }

    public function consultarVistaInmueble($id) {
        $objConexion = new Connection();
        $conexion = $objConexion->open();

        $consultar = "SELECT * FROM inmuebles WHERE id=:id";
        $result = $conexion->prepare($consultar);
        $result->bindParam(':id', $id, PDO::PARAM_INT); 
        $result->execute();

        $f = $result->fetch(PDO::FETCH_ASSOC); 
        return $f;
    }    

    // Eliminar inmueble
    public function eliminarInmueble($id) {
        $objConexion = new Connection();
        $conexion = $objConexion->open();

        $eliminar = "DELETE FROM inmuebles WHERE id=:id";
        $result = $conexion->prepare($eliminar);
        $result->bindParam(':id', $id);
        $result->execute();
        echo "<script> alert('Inmueble eliminado exitosamente')</script>";
        echo "<script> location.href='../../Views/interfaces/inmoApartamentos.php'</script>";
    }

    // Consultar inmueble para edición
    public function consultarInmuebleEdit($id) {
        $objConexion = new Connection();
        $conexion = $objConexion->open();

        $consultar = "SELECT * FROM inmuebles WHERE id=:id";
        $result = $conexion->prepare($consultar);
        $result->bindParam(':id', $id);
        $result->execute();

        $f = null;
        while ($resultado = $result->fetch()) {
            $f[] = $resultado;
        }
        return $f;
    }

    // Editar inmueble
    public function editarInmueble($id, $tipo, $categoria, $precio, $tamano, $ciudad, $barrio) {
        $objConexion = new Connection();
        $conexion = $objConexion->open();

        $modificar = "UPDATE inmuebles SET tipo=:tipo, categoria=:categoria, precio=:precio, tamano=:tamano, ciudad=:ciudad, barrio=:barrio WHERE id=:id";
        $result = $conexion->prepare($modificar);
        $result->bindParam(':id', $id);
        $result->bindParam(':tipo', $tipo);
        $result->bindParam(':categoria', $categoria);
        $result->bindParam(':precio', $precio);
        $result->bindParam(':tamano', $tamano);
        $result->bindParam(':ciudad', $ciudad);
        $result->bindParam(':barrio', $barrio);
        $result->execute();

        echo "<script> alert('Los datos del inmueble han sido modificados correctamente')</script>";
        echo "<script> location.href='../../Views/interfaces/inmoApartamentos.php'</script>";
    }
    public function consultarSolicitudes() {
        $objConexion = new Connection();
        $conexion = $objConexion->open();
    
        $consultar = "
            SELECT 
                solicitudes.id_sol, 
                solicitudes.fecha, 
                usuarios.id AS user_id, 
                usuarios.nombres, 
                usuarios.apellidos, 
                usuarios.telefono, 
                usuarios.correo, 
                usuarios.rol, 
                inmuebles.id AS inmueble_id, 
                inmuebles.tipo, 
                inmuebles.categoria, 
                inmuebles.precio, 
                inmuebles.tamano, 
                inmuebles.ciudad, 
                inmuebles.barrio, 
                inmuebles.foto 
            FROM solicitudes
            JOIN usuarios ON solicitudes.id_user = usuarios.id
            JOIN inmuebles ON solicitudes.id_inm = inmuebles.id";
            
        $result = $conexion->prepare($consultar);
        $result->execute();
    
        $f = [];
        while ($resultado = $result->fetch(PDO::FETCH_ASSOC)) {
            $f[] = $resultado;
        }
        return $f;
    }
    public function consultarSolicitudPorId($id_sol) {
        $objConexion = new Connection();
        $conexion = $objConexion->open();
    
        $consultar = "
            SELECT 
                solicitudes.id_sol, 
                solicitudes.fecha, 
                usuarios.nombres, 
                usuarios.apellidos, 
                usuarios.telefono, 
                usuarios.correo, 
                inmuebles.tipo, 
                inmuebles.categoria, 
                inmuebles.precio, 
                inmuebles.tamano, 
                inmuebles.ciudad, 
                inmuebles.barrio, 
                inmuebles.foto 
            FROM solicitudes 
            JOIN usuarios ON solicitudes.id_user = usuarios.id
            JOIN inmuebles ON solicitudes.id_inm = inmuebles.id
            WHERE solicitudes.id_sol = :id_sol";
            
        $result = $conexion->prepare($consultar);
        $result->bindParam(':id_sol', $id_sol, PDO::PARAM_INT);
        $result->execute();
    
        return $result->fetch(PDO::FETCH_ASSOC);
    }  
}

?>
